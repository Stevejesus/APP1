// Steve Portella

package com.example.app1_2024_25;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    // Definir Variables
    private EditText nume1;
    private EditText nume2;
    private TextView result;

    private Button sumaButton;
    private Button restaButton;
    private Button multiButton;
    private Button diviButton;
    private Button expoButton;
    private Button modButton;

    //
    @Override
    protected void onCreate(Bundle savedInstaceState) {
        super.onCreate(savedInstaceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Configuración de vistas
        nume1 = (EditText)findViewById(R.id.numero1);
        nume2 = (EditText)findViewById(R.id.numero2);
        result = (TextView)findViewById(R.id.resul);

        sumaButton = findViewById(R.id.suma);
        restaButton = findViewById(R.id.resta);
        multiButton = findViewById(R.id.multiplicar);
        diviButton = findViewById(R.id.dividir);
        expoButton = findViewById(R.id.exponente);
        modButton = findViewById(R.id.mod);

        // Evento del clic en el boton suma +
        sumaButton.setOnClickListener(v -> {
            // Obtener los valores de los EditText y convertirlos a enteros
            String val1 = nume1.getText().toString();
            String val2 = nume2.getText().toString();

            //
            int resultado = validarYCalcular(val1, val2, "suma");
            result.setText(String.valueOf(resultado));
        });

        restaButton.setOnClickListener(v -> {
            String val1 = nume1.getText().toString();
            String val2 = nume2.getText().toString();
            int resultado = validarYCalcular(val1, val2, "resta");
            result.setText(String.valueOf(resultado));
        });

        multiButton.setOnClickListener(v -> {
            String val1 = nume1.getText().toString();
            String val2 = nume2.getText().toString();
            int resultado = validarYCalcular(val1, val2, "multiplicacion");
            result.setText(String.valueOf(resultado));
        });

        diviButton.setOnClickListener(v -> {
            String val1 = nume1.getText().toString();
            String val2 = nume2.getText().toString();
            int resultado = validarYCalcular(val1, val2, "division");
            result.setText(String.valueOf(resultado));
        });

        expoButton.setOnClickListener(v -> {
            String val1 = nume1.getText().toString();
            String val2 = nume2.getText().toString();
            int resultado = validarYCalcular(val1, val2, "exponente");
            result.setText(String.valueOf(resultado));
        });

        modButton.setOnClickListener(v -> {
            String val1 = nume1.getText().toString();
            String val2 = nume2.getText().toString();
            int resultado = validarYCalcular(val1, val2, "mod");
            result.setText(String.valueOf(resultado));
        });

    }

    private int validarYCalcular(String val1, String val2, String operacion) {
        if (val1.isEmpty() || val2.isEmpty()) {
            result.setText("Por favor, ingrese ambos números.");
            return 0; // O puedes lanzar una excepción si prefieres
        }

        int num1 = Integer.parseInt(val1);
        int num2 = Integer.parseInt(val2);

        return calcularOperacion(num1, num2, operacion);
    }


    private int calcularOperacion(int num1, int num2, String operation) {
        // Realizar la operación correspondiente
        switch (operation) {
            case "suma":
                return suma(num1, num2);
            case "resta":
                return resta(num1, num2);
            case "multiplicacion":
                return multi(num1, num2);
            case "division":
                return num2 != 0 ? divi(num1, num2) : 0; // Manejar división por cero
            case "exponente":
                return num2 !=0 ? expo(num1, num2) : 1;
            case "mod":
                return num2 !=0 ? mod(num1, num2) : 0;
            default:
                return 0;
        }
    }

    static int suma(int a, int b) {
        return a + b;
    }

    static int resta(int a, int b) {
        return a - b;
    }

    static int multi(int a, int b) {
        return a * b;
    }

    static int divi(int a, int b) {
        return a / b;
    }

    static int expo(int a, int b) {
        int exp = 1; //c = 0,
        if (b == 0) return 1;

        for (int i=0; i < b; i++) {
            exp *= a;
        }

        return exp;

        /*
        do {
            exp = exp * a;
            i++;
        } while (b>i);
        c = exp; */
    }

    static int mod(int a, int b) {
        return a % b;
    }
}
